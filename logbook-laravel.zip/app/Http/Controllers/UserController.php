<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Position;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    public function index()
    {
        // Fetch all users with pagination
        $users = User::paginate(10);
		$positions = Position::paginate(10);
        return view('users.index', compact('users', 'positions'));
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'first_name' => 'required|string',
            'last_name' => 'required|string',
            'username' => 'required|string|unique:users,username',
            'email' => 'required|email|unique:users,email',
            'signature' => 'required|string',
            'access_level' => 'required|integer',
            'position' => 'required|string',
            'address' => 'required|string',
            'phone_number' => 'required|string',
            'country' => 'required|string',
            'city' => 'required|string',
            'state' => 'required|string',
            'zip_code' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json(['success' => false, 'message' => $validator->errors()->first()]);
        }

        // Create new user
        $user = new User();
        $user->first_name = $request->first_name;
        $user->last_name = $request->last_name;
        $user->username = $request->username;
        $user->email = $request->email;
        $user->signature = $request->signature;
        $user->access_level = $request->access_level;
        $user->position = $request->position;
        $user->address = $request->address;
        $user->phone_number = $request->phone_number;
        $user->country = $request->country;
        $user->city = $request->city;
        $user->state = $request->state;
        $user->zip_code = $request->zip_code;
        $user->password = Hash::make('defaultpassword');  // Default password
        $user->save();

        // Flash success message to the session
        session()->flash('successMessage', 'User added successfully.');

        return response()->json(['success' => true, 'message' => 'User added successfully']);
    }

    public function edit($id)
    {
        // Get user details
        $user = User::findOrFail($id);
        return response()->json(['success' => true, 'user' => $user]);
    }

    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'first_name' => 'required|string',
            'last_name' => 'required|string',
            'username' => 'required|string|unique:users,username,' . $id,
            'email' => 'required|email|unique:users,email,' . $id,
            'signature' => 'required|string',
            'access_level' => 'required|integer',
            'position' => 'required|string',
            'address' => 'required|string',
            'phone_number' => 'required|string',
            'country' => 'required|string',
            'city' => 'required|string',
            'state' => 'required|string',
            'zip_code' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json(['success' => false, 'message' => $validator->errors()->first()]);
        }

        // Update user
        $user = User::findOrFail($id);
        $user->first_name = $request->first_name;
        $user->last_name = $request->last_name;
        $user->username = $request->username;
        $user->email = $request->email;
        $user->signature = $request->signature;
        $user->access_level = $request->access_level;
        $user->position = $request->position;
        $user->address = $request->address;
        $user->phone_number = $request->phone_number;
        $user->country = $request->country;
        $user->city = $request->city;
        $user->state = $request->state;
        $user->zip_code = $request->zip_code;
        $user->save();

        // Flash success message to the session
        session()->flash('successMessage', 'User updated successfully.');

        return response()->json(['success' => true, 'message' => 'User updated successfully']);
    }

    public function destroy($id)
    {
        // Delete user
        $user = User::findOrFail($id);
        $user->delete();

        // Flash success message to the session
        session()->flash('successMessage', 'User deleted successfully.');

        return response()->json(['success' => true, 'message' => 'User deleted successfully']);
    }
}

