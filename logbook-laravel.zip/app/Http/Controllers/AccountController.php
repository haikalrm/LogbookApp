<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules\Password;

class AccountController extends Controller
{
    /**
     * Menampilkan halaman utama pengaturan akun (tab Account).
     */
    public function settings(Request $request)
    {
        return view('account.settings', [
            'user' => $request->user()
        ]);
    }

    /**
     * Menampilkan halaman pengaturan keamanan (tab Security).
     */
    public function security(Request $request)
    {
        $user = $request->user();
        $recentDevices = $user->recentDevices()->take(5)->get();

        return view('account.security', [
            'user' => $user,
            'recentDevices' => $recentDevices
        ]);
    }

    /**
     * Menampilkan halaman pengaturan notifikasi (tab Notifications).
     */
    public function notifications(Request $request)
    {
        $user = $request->user();
        $notifications = $user->notifications()->paginate(15);

        return view('account.notifications', [
            'user' => $user,
            'notifications' => $notifications
        ]);
    }

    /**
     * Meng-handle update data profil dari tab Account.
     */
    public function updateDetails(Request $request)
    {
        $user = $request->user();
        
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'phone_number' => ['nullable', 'string', 'max:20'],
            'address' => ['nullable', 'string', 'max:255'],
            'city' => ['nullable', 'string', 'max:255'],
            'state' => ['nullable', 'string', 'max:255'],
            'zip_code' => ['nullable', 'string', 'max:10'],
            'country' => ['nullable', 'string', 'max:255'],
            'profile_picture' => ['nullable', 'image', 'max:1024'], // max 1MB
        ]);

        if ($request->hasFile('profile_picture')) {
			$extension = $request->file('profile_picture')->getClientOriginalExtension();
			$fileName = uniqid() . '.' . $extension;
			$path = $request->file('profile_picture')->move(public_path('assets/img/profile'), $fileName);
			$validated['profile_picture'] = 'assets/img/profile/' . $fileName;
        }

        $user->update($validated);
        
        session()->flash('successMessage', 'Account details updated successfully!');
		return back();
    }
	
    public function updatePassword(Request $request)
	{
		$validated = $request->validate([
			'current_password' => ['required', 'current_password'],
			'password' => ['required', Password::min(8)->mixedCase()->numbers()->symbols(), 'confirmed'],
		]);
		if (!Hash::check($validated['current_password'], $request->user()->password)) {
			session()->flash('errorMessage', 'Current password is incorrect.');
			return back();
		}

		$request->user()->update([
			'password' => Hash::make($validated['password']),
		]);

		session()->flash('successMessage', 'Password updated successfully!');
		
		return back();
	}
}