<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Position;

class PositionController extends Controller
{
    public function index()
    {
        $positions = Position::paginate(10);
        return view('positions.index', compact('positions'));
    }

    public function update(Request $request)
    {
        $validator = validator($request->all(), [
            'position_name' => 'required|string|max:255',
            'position_id' => 'required|integer',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validasi gagal: ' . $validator->errors()->first()
            ]);
        }

        $position = $request->position_id > 0 ? Position::find($request->position_id) : new Position;
        $position->name = $request->position_name;

        if ($position->save()) {
            session()->flash('successMessage', $request->position_id > 0 ? 'Posisi berhasil diperbarui' : 'Posisi baru berhasil ditambahkan');

            return response()->json([
                'success' => true,
                'message' => 'Posisi berhasil disimpan'
            ]);
        }

        session()->flash('errorMessage', 'Gagal menyimpan posisi');

        return response()->json([
            'success' => false,
            'message' => 'Gagal menyimpan posisi'
        ]);
    }

    public function delete(Request $request)
    {
        $validator = validator($request->all(), [
            'position_id' => 'required|integer|exists:positions,no',
        ]);

        if ($validator->fails()) {
            session()->flash('errorMessage', 'Posisi tidak ditemukan');
            
            return response()->json([
                'success' => false,
                'message' => 'Posisi tidak ditemukan'
            ]);
        }

        $position = Position::find($request->position_id);
        if ($position && $position->delete()) {
            session()->flash('successMessage', 'Posisi berhasil dihapus');
            
            return response()->json([
                'success' => true,
                'message' => 'Posisi berhasil dihapus'
            ]);
        }

        return response()->json([
            'success' => false,
            'message' => 'Gagal menghapus posisi'
        ]);
    }
}
