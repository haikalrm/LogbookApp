@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Logbook ({{ strtoupper($unit->name) }})</h1>

    <a href="{{ route('logbook.create', $unit->id) }}" class="btn btn-primary">Add New Logbook</a>

    <table class="table mt-4">
        <thead>
            <tr>
                <th>No</th>
                <th>ID</th>
                <th>Tanggal Kegiatan</th>
                <th>Shift</th>
                <th>Judul</th>
                <th>Author</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($logbooks as $key => $logbook)
            <tr>
                <td>{{ $key + 1 }}</td>
                <td>{{ $logbook->id }}</td>
                <td>{{ $logbook->tanggal_kegiatan }}</td>
                <td>{{ $logbook->shift == 0 ? 'Pagi' : ($logbook->shift == 1 ? 'Siang' : 'Malam') }}</td>
                <td>{{ $logbook->judul }}</td>
                <td>{{ $logbook->author->name ?? 'Deleted User' }}</td>
                <td>
                    <span class="badge {{ $logbook->status == 0 ? 'bg-warning' : 'bg-success' }}">
                        {{ $logbook->status == 0 ? 'Pending' : 'Approved' }}
                    </span>
                </td>
                <td>
                    <a href="{{ route('logbook.edit', $logbook->id) }}" class="btn btn-sm btn-secondary">Edit</a>
                    <a href="{{ route('logbook.view', $logbook->id) }}" class="btn btn-sm btn-info">View</a>
                    <form action="{{ route('logbook.destroy', $logbook->id) }}" method="POST" style="display:inline;">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                    </form>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>

    <p>Total Logbooks: 1</p>
</div>
@endsection
