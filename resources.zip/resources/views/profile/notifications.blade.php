@extends('layouts.app')

@section('content')
<div class="container">
  <h4>Notifications for {{ $user->name }}</h4>
  <table id="notifications" class="table table-bordered">
    <thead>
      <tr>
        <th>Message</th>
        <th>Date</th>
      </tr>
    </thead>
    <tbody>
      @foreach($notifications as $notify)
        <tr>
          <td>
            <div class="d-flex">
              <img src="/assets/img/profile/{{ $notify->profile }}" class="rounded-circle me-2" width="40">
              <div>
                <strong>{{ $notify->title }}</strong><br>
                <small>{{ $notify->body }}</small>
              </div>
            </div>
          </td>
          <td>{{ $notify->date->diffForHumans() }}</td>
        </tr>
      @endforeach
    </tbody>
  </table>
</div>
@endsection

@push('scripts')
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script>
  $(function() {
    $('#notifications').DataTable();
  });
</script>
@endpush
