@extends('layouts.app')

@section('content')
<div class="container">
  <div class="card mb-4">
    <div class="card-body">
      <h4>{{ $user->name }}</h4>
      <p>{{ $user->position }} • {{ $user->city }}</p>
      <p>Joined {{ \Carbon\Carbon::parse($user->joined)->format('F Y') }}</p>
    </div>
  </div>

  <h5>Timeline Activity</h5>
  <ul class="list-group">
    @forelse($notifications as $notify)
      <li class="list-group-item">
        <strong>{{ $notify->title }}</strong>
        <p>{{ $notify->body }}</p>
        <small class="text-muted">{{ $notify->date->diffForHumans() }}</small>
      </li>
    @empty
      <li class="list-group-item">No timeline yet on this user</li>
    @endforelse
  </ul>
</div>
@endsection
